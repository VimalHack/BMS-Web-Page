// JavaScript Document
/*----------- Topband -----------*/
function newTopBand(){
	var bandOffset = $('#topband').offset().top;
	$(window).scroll(function(event){
		var newTopband = $(this).scrollTop();
		if (newTopband >= bandOffset)
		{
			$('.topband').addClass('fixed');
		}else{
			$('.topband').removeClass('fixed');
		}
	});}
if($('#topband').length){$(document).ready(function(){setTimeout(newTopBand,200)});$(window).resize(function(){newTopBand()});}

$(document).ready(function(e) {
    $('#topband span').click(function(e) {
		var target = $(this).attr('data-href');
		$('#topband span').removeClass('bandact');
		$(this).addClass('bandact');
		var locLength = $('#'+target).offset().top;
		locLength = Number(locLength-40);
		$('html,body').animate({scrollTop : locLength}, 400);
    });
});


$(document).ready(function(e) {
    $('.dashboard').each(function(index, element) {
       var blabla = $(this).html();
		$('#searchList').prepend(blabla);
		$('#searchList li a').removeAttr('class');
		$('#searchList li a span.dicon').remove();
		$('#searchList li a span.dashboardtxt').removeAttr('class');
    });
});

$("#search").focus(function() {
	$("#searchList").show();
	$("#search").on('input',function(e) {
		var searchtext = $(this).val();
		$("#searchList li").each(function() {
			if ($(this).text().search(new RegExp("^"+searchtext, 'i')) < 0) {
				$(this).css("display" , "none");
			} 
			else 
			{
				$(this).css("display" , "block");
			}
			if($("#search").val() == "")
			{
				$("#searchList li").hide();
			}
			else
			{
			}
		});
		$("#searchList li a").on('click', function() {
			$("#searchList li").hide();
			$("#search").val($(this).children('span').html());
		});
	});
});
/*$(".srch").mouseout(function(e) {
    $("#searchList").hide();
});*/
$('.mobicon').click(function(e) {
    $('.topband ul li.drop').slideToggle();
});