var overlay=document.querySelector('.overlay');
var content=document.querySelector('.content');

var run='<span id="tag"> Do you want to run?</span><br><br><div class="run" onclick="runtask(this.value)">Run</div>';
    
var progress='<div class="loader"></div>';
    
var scs='   <div><img src="{% static "image/success.png" %}"  class="simg" /></div> <br> <hr> <div class="links" id="links" >';

function showpopup(taskname)
{
  overlay.style.visibility="visible";
  overlay.style.opacity="1";
  content.innerHTML=run;
  var runbtn=document.querySelector('.run');
  runbtn.value=taskname;
}

function closeoverlay()
{
  overlay.style.visibility="hidden";
  overlay.style.opacity="0";
  console.log("close this function");
}


function prog()
{
      content.innerHTML=progress;
}

function success(filenames)
{
  var fl='';
  console.log(filenames);
  Object.keys(filenames).forEach(element=>{
  fl+='<div class="download"><a href="'+filenames[element]+'">'+element+'</a></div>';
        });
  content.innerHTML=scs+fl+'</div>';
}



function runtask(taskname)
{

const xhr = new XMLHttpRequest();
xhr.onload = () => {
    
    setTimeout(function(){ 
     console.log("the data is completed"+xhr.status);
console.log(xhr.response);
var data=JSON.parse(xhr.response);
console.log(data.status);
success(data.filenames);
     }, 3000);
     
      
    };
    
    
    
    // listen for `error` event
    xhr.onerror = () => {
        console.error('Download failed.');
    }
    
    
    
    // listen for `progress` event
    xhr.onprogress = (event) => {
     console.log("progressing...");
      prog();
    }
 
    
    // open and send request
    xhr.open('GET', "/filename?t="+taskname,true);
    xhr.send();
    }